/*
* FILE				: animal.cpp
* PROJECT			: WDD assignment 02
* PROGRAMMERS		:
*   Minchul Hwang  ID: 8818858
* FIRST VERSION		: October, 9th, 2023
* DESCRIPTION		:
*	This program is for creating CGI exe.
*	This EXE program imports photos, brief descriptions, and css files of animals at a specified location
*	CGI html uses the GET method and plays the role of receiving the letters that match it.
*/

#include <stdlib.h>
#include<stdio.h>
#include<iostream>
#include<string.h>
#pragma warning(disable : 4996)

int main(void) {

	char* data1;						// A variable to save the key and pair
	char* UserName = NULL;				// A variable to save user name
	char* AnimalSelect = NULL;			// A variable to save selected animal
	char cssPath[40] = "./theZoo/";		// A relative path to get css file
	char buffer[81] = "./theZoo/";		// A relative path to get animal's picture and description

	printf("Content-type:text/html\r\n\r\n");
	printf("<html><head><title>cgi-zoo using GET method</title>\n");
	printf("</head>\n");
	printf("<body>\n");
	printf("<h1>Pet Facts!</h1>\n");
	
	printf("<hr>\n");

	data1 = getenv("QUERY_STRING");		// Get Query string from CGI html
	if (data1 != NULL) {
		// Allocate dynamic memory to get string from html
		UserName = (char*)malloc(30 * sizeof(char));
		AnimalSelect = (char*)malloc(30 * sizeof(char));

		if ((sscanf(data1, "UserName=%[^&]&AnimalSelect=%s", UserName, AnimalSelect) == 2)) {		// Set user name and animal in variable which is declared in C file
			printf("<h3>Hello, %s!</h3>\n", UserName);							
			printf("<h3>Your favorite pet is a %29s.</h3>\n", AnimalSelect);
		}
		else {
			printf("Invalid data received.\n");
		}

		// Set path to get css file 
		if (AnimalSelect != NULL && cssPath != NULL) {
			strcat(cssPath, AnimalSelect);
			strcat(cssPath, ".css");
		}
		printf("<link rel = \"STYLESHEET\" type=\"text/css\" href=\"%s\">\n", cssPath);
	}
	else {
		printf("No data received.\n");
	}
	printf("<hr>\n");
	
	// Set path to get animal's picture and description
	if (AnimalSelect != NULL && buffer != NULL) {
		strcat(buffer, AnimalSelect);
		strcat(buffer, ".txt");
	}

	// using file IO to open the description file
	FILE* fp = NULL;
	fp = fopen(buffer, "r");
	// if File does not exist
	if (fp == NULL) {
		printf("Can't open file\n");
		return 1;
	}
	else {
		printf("<table><td>");
		printf("<img src=./theZoo/%s.jpg> ", AnimalSelect);			// Get the picture of animal
		printf("</td><td>");
		
		// Get description from text file which is set as animal name
		while (fgets(buffer, sizeof(buffer), fp) != NULL) {
			printf("<div>%s</div>\n", buffer);					
		}
		printf("</td></table>");
	}

	//error check for file.
	if (ferror(fp) != 0) {
		printf("There is an error on the file.\n");
		return 2;
	}

	// check error to close file
	if (fclose(fp) != 0) {
		printf("Can't close file opened for writing\n");
		return 3;
	}

	// delete allocated memory
	free(UserName);
	free(AnimalSelect);
	
	printf("</body></html>");
	return 0;
}